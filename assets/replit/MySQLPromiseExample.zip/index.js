var mysql = require('mysql');
const Database = require('./mysqldatabase.js');

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
// control-shift-S to bring up repl.it terminal
// export DBHOST="db4free.net"
// ...
// DBHOST=db4free.net DBUSER=x DBNAME=y DBPASSWORD=z node index.js
// then...
// node index.js

// con is global to this file
let con = new Database({
  host: process.env.DBHOST,
  user: process.env.DBUSER,
  password: process.env.DBPASSWORD,
  database: process.env.DBNAME
});

console.log("Connecting to " + process.env.DBHOST);

query = "CREATE TABLE IF NOT EXISTS people (personId INTEGER AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(255), age INTEGER)";

con.query(query)
  .then((result) => { 
    console.log(result);

    query = "INSERT INTO people (name, age) VALUES ('Bill', 38)";
    return con.query(query); // why return?
  }).then((result) => {
    console.log(result);

    query = "UPDATE people SET age=38 WHERE name='Bill'";
    return con.query(query);
  }).then((result) => {
    console.log(result);

    query = "INSERT INTO people (name, age) VALUES ('Alex', 21)";
    return con.query(query);
  }).then((result) => {
    console.log(result);

    query = "SELECT * FROM people ORDER BY NAME ASC";
    return con.query(query);
  }).then((result) => {
    console.log(result);

    query = "DELETE FROM people WHERE name='Bill'";
    return con.query(query);
  }).then((result) => {
    console.log(result);

    query = "DROP TABLE people";
    return con.query(query);
  }).then((result) => {
    console.log(result);

    process.exit(0);
  }, err => { // could catch at every step
        return database.close().then( () => { throw err; } )
  });

// Whatever is here executes immediately after the first con.query()