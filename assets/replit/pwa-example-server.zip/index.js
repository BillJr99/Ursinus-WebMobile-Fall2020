const express = require('express');

const app = express();

const courses = [
  { dept: "CS", coursenum: "173", coursename: "Intro to Computer Science", link: "http://www.billmongan.com/Ursinus-CS173-Fall2020", img: "https://www.billmongan.com/files/media/software-iotframework/simbaby.jpg"},
  { dept: "CS", coursenum: "174", coursename: "Object Oriented Programming", link: "http://www.ctralie.com/Teaching/CS174_F2020/", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Iris_dataset_scatterplot.svg/512px-Iris_dataset_scatterplot.svg.png"},
  { dept: "CS", coursenum: "471", coursename: "Web and Mobile Development", link: "http://www.billmongan.com/Ursinus-WebMobile-Fall2020", img: "https://www.billmongan.com/files/media/software-clusternav/clusternav.jpg"}
];

app.get('/', (req, res) => {
  console.log("Request Received");
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.send(JSON.stringify(courses));
});

app.listen(3000, () => {
  console.log('server started');
});