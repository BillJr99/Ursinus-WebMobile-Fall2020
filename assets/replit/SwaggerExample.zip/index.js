// https://www.codementor.io/@olatundegaruba/nodejs-restful-apis-in-10-minutes-q0sgsfhbd
/* 
THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// https://levelup.gitconnected.com/the-simplest-way-to-add-swagger-to-a-node-js-project-c2a4aa895a3c
// https://swagger.io/docs/specification/2-0/basic-structure/
// https://levelup.gitconnected.com/swagger-time-to-document-that-express-api-you-built-9b8faaeae563

function listItems() {
  console.log("test");
}

var express = require('express'); // control-shift-S to bring up shell in repl.it and npm install express / other packages
var bodyParser = require('body-parser')
var app = express();
var port = 5000; // the port is automatically routed by the repl.it domain

app.get('/', (req, res) => {
  res.send('Hello World!')
})

const swaggerJsdoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

const swaggerDocument = {
  swagger: "2.0",
  info: {
    title: "Example Item API",
    description: "Insert and retrieve items from a datastore",
    version: 1.0
  },
  host: "localhost",
  basePath: "/api/v1",
  schemes: ['http'],
  tags: ['Items'],
  "components": {
    "schemas": {
      "ItemSchema": {
        type: "object",
        "name": {
          type: "string"
        },
        "price": {
          type: "number"
        },
        "status": {
          type: "string"
        }
      }
    }
  },
  paths: {
    "/items": {
      "get": {
        "description": "Get all items from the datastore",
        "responses": {
          "200": {
            "description": "A list of items",
            "content": {
              "application/json": {
                "schema": {
                  "type": "array",
                  "items": {
                    "$ref": "#/components/schemas/ItemSchema"
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

app.use('/api/doc', swaggerUi.serve, swaggerUi.setup(swaggerDocument))

// Allow multipart form encoding and json body
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.listen(port);

