// https://www.codementor.io/@olatundegaruba/nodejs-restful-apis-in-10-minutes-q0sgsfhbd
/* 
THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*/

// https://levelup.gitconnected.com/the-simplest-way-to-add-swagger-to-a-node-js-project-c2a4aa895a3c
// https://swagger.io/docs/specification/2-0/basic-structure/
// https://levelup.gitconnected.com/swagger-time-to-document-that-express-api-you-built-9b8faaeae563

var express = require('express'); // control-shift-S to bring up shell in repl.it and npm install express / other packages
var bodyParser = require('body-parser')
var app = express();
var port = 5000; // the port is automatically routed by the repl.it domain

// Replace this with your usual web service definitions or models/routes
app.get('/', (req, res) => {
  res.send('Hello World!')
})

// Swagger requires cors.  We'll allow everyone for this example.
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next(); // what does this do?
});

const swaggerUi = require("swagger-ui-express");

const swaggerDocument = {
  "swagger": "2.0",
  "info": {
    "description": "Demo Swagger ItemServer Example",
    "version": "1.0.0",
    "title": "ItemServer",
    "contact": {
      "email": "billmongan@gmail.com"
    }
  },
  "host": "https://localhost",
  "basePath": "/api/v1",
  "tags": [
    {
      "name": "item",
      "description": "An Item for Insertion or Retrieval"
    }
  ],
  "schemes": [
    "https",
    "http"
  ],
  "paths": {
    "/item": {
      "post": {
        "tags": [
          "item"
        ],
        "summary": "Add an item to the datastore",
        "description": "An item is anything with a name, price, and taxable status",
        "operationId": "addItem",
        "consumes": [
          "application/json"
        ],
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "in": "body",
            "name": "body",
            "description": "An Item object",
            "required": true,
            "schema": {
              "$ref": "#/definitions/item"
            }
          }
        ],
      },
      "get": {
        "tags": [
          "item"
        ],
        "summary": "Get all items",
        "description": "Retrieve a list of all items",
        "operationId": "getItems",
        "produces": [
          "application/json"
        ],
        "responses": {
          "200": {
            "description": "Retrieved items",
            "schema": {
              "type": "array",
              "items": {
                "$ref": "#/definitions/item"
              }
            }
          }
        }
      }
    },
    "/item/{id}": {
      "get": {
        "tags": [
          "item"
        ],
        "summary": "Find an item by ID",
        "description": "Retrieve one item given its ID",
        "operationId": "findItem",
        "produces": [
          "application/json"
        ],
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "description": "Item ID to retrieve",
            "required": true,
            "type": "integer",
            "format": "int64"
          }
        ],
        "responses": {
          "200": {
            "description": "Retrieved item",
            "schema": {
              "$ref": "#/definitions/item"
            }
          }
        }
      }
    }
  },
  "definitions": {
    "item": {
      "type": "object",
      "properties": {
        "id": {
          "type": "integer",
          "format": "int64"
        },
        "name": {
          "type": "string",
        },
        "price": {
          "type": "number",
          "format": "double"
        },
        "status": {
          "type": "string",
          "description": "Taxable Status",
          "enum": [
            "taxable",
            "non-taxable"
          ]
        }
      }
    }
  }
}

app.use('/api/doc', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Allow multipart form encoding and json body
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.listen(port);

