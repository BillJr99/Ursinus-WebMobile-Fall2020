const courses = [
  { dept: "CS", coursenum: "173", coursename: "Intro to Computer Science", link: "http://www.billmongan.com/Ursinus-CS173-Fall2020", img: "images/simbaby.jpg"},
  { dept: "CS", coursenum: "174", coursename: "Object Oriented Programming", link: "http://www.ctralie.com/Teaching/CS174_F2020/", img: "images/Spectrogram.png"},
  { dept: "CS", coursenum: "471", coursename: "Web and Mobile Development", link: "http://www.billmongan.com/Ursinus-WebMobile-Fall2020", img: "images/clusternav.jpg"}
];

const listCourses = () => {
  const contents = document.querySelector(".contents");

  let content = "";

  courses.forEach(
    ({dept, coursenum, coursename, link, img}) => (
      content += `
        <a href="${link}">
        <div class="course">
          <img class="banner" src="${img}" alt="Course banner for ${dept} ${coursenum}" />
          <h1>${dept} ${coursenum}</h1>
          ${coursename}
        </div>
        </a>
      `
    )
  )

  contents.innerHTML = content;
}

document.addEventListener("DOMContentLoaded", listCourses);

// Register service worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker
      .register("./serviceWorker.js")
      .then(res => console.log("service worker registered"))
      .catch(err => console.log("service worker not registered", err))
  })
}