import socket

def read_file(filepath):
  filedata = ""

  try:
    f = open(filepath, "r")
    for line in f:
      #print(line)
      filedata += line
  except:
    print("Error reading file " + filepath)

  return filedata

def process(httprequestdata, conn):
  #print(httprequestdata)
  lines = httprequestdata.split("\r\n")
  requestLine = lines[0]
  requestTokens = requestLine.split(" ")
  filePath = requestTokens[1]
  #print(filePath)

  filedata = read_file("." + filePath)
  #print(filedata)

  send_http_response(conn, filedata)

def server(port):
    host = "0.0.0.0" # ourselves
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen()
    
    while True: # accept one connection after another; do new requests have to wait while we process each one?
        conn, addr = sock.accept()
        data = ""
        while True:
            chunk = conn.recv(1024)
            if not chunk:
                break
            data += chunk.decode("utf-8")

            #print("Got " + chunk.decode("utf-8"))

            if data.endswith("\r\n\r\n"):
              break
            
        # Process the request here
        #print("out!")
        #print(data)
        process(data, conn)

def send_data(conn, data):
  conn.sendall(data.encode())

def send_http_response(conn, filedata):
  httpdata = "HTTP/1.1 200 OK\r\n"
  httpdata += "Content-Length: " + str(len(filedata)) + "\r\n"
  httpdata += "\r\n"
  httpdata += filedata
  httpdata += "\r\n"

  send_data(conn, httpdata)

server(5012)

# Try going to
# https://httpserver.billjr99.repl.co/main.py
# or...
# https://httpserver.billjr99.repl.co/main.py
# which repl.it redirects to port being used in the call to server()