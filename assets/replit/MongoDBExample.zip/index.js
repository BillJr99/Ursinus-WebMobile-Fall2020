var mongo = require('mongodb');

// https://www.w3schools.com/nodejs/nodejs_mongodb.asp

// mongodb.com
// 1. Add a cluster
// 2. Add a user
// 3. Set network access
// 4. Click Connect on cluster to get connection string
// 5. Terminate cluster + delete network access and user when done
var MongoClient = mongo.MongoClient;

// control-shift-S to launch repl.it shell and set these variables
var user = process.env.DBUSER;
var password = process.env.DBPASSWORD;
var dbname = process.env.DBNAME;

var url = "mongodb+srv://" + user + ":" + password + "@cluster0.t74xp.mongodb.net/" + dbname + "?retryWrites=true&w=majority";

MongoClient.connect(url, {poolSize: 10, ssl: true}, function(err, db) {
  if (err) throw err;
  console.log("Database created!");

  dbo = db.db(dbname);
  collection = dbo.collection("myCollection")

  obj = {"name": "Alex", "age": 38};
  collection.insertOne(obj, function(err, res) {
    if(err) throw err;

    console.log("Inserted!");
    console.log(res);
  });

  obj = {"name": "Bill", "age": 38};

  collection.insertOne(obj, function(err, res) {
    if(err) throw err;

    console.log("Inserted!");
    console.log(res);

    collection.find({age: 38}).sort({name: 1}).toArray(function(err, result) {
      if(err) throw err;

      console.log("Query Found!");
      console.log(result);

      collection.deleteMany({name: "Bill"}, function(err, obj) {
        if(err) throw err;
        console.log("Deleted!");

        newvalues = { $set: {age: 39 } };

        collection.updateOne({name: "Alex"}, newvalues, function(err, res) {
          console.log("Updated!");

          collection.find().toArray(function(err, result) {
            if(err) throw err;

            console.log("Query Found!");
            console.log(result);
          
            collection.drop();

            db.close(); // what happens if this delete is moved down outside of this block, or to the bottom of this program?          
          });
        });
      });
    });
  });
});