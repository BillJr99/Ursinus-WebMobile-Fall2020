# https://repl.it/talk/learn/Flask-Tutorial-Part-1-the-basics/26272

import flask

app = flask.Flask(__name__, template_folder="templates", static_folder="static")

@app.route('/')
def home():
  return flask.render_template('base.html')

if __name__ == "__main__":
  app.run(host='0.0.0.0', port=8082)