// https://www.js-tutorials.com/nodejs-tutorial/simple-example-of-nodejs-express-with-mssql/
var bodyParser = require("body-parser");
var sql = require("mssql");
var cors = require('cors');
const Database = require('./mysqldatabase.js');
var express = require('express');
var app = express(); 
 
// Body Parser Middleware
app.use(bodyParser.json()); 
app.use(cors());
 
//Setting up server
 var server = app.listen(process.env.PORT || 8080, function () {
    var port = server.address().port;
    console.log("App now running on port", port);
 });

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
// control-shift-S to bring up repl.it terminal
// export DBHOST="db4free.net"
// ...
// DBHOST=db4free.net DBUSER=x DBNAME=y DBPASSWORD=z node index.js
// then...
// node index.js

// con is global to this file
let con = new Database({
    host: process.env.DBHOST,
    user: process.env.DBUSER,
    password: process.env.DBPASSWORD,
    database: process.env.DBNAME
});

app.get("/api/v1/person", function(req , res){
	query = "SELECT * FROM people";
  con.query(query).then((result) => { 
    console.log(result);
    res.end(JSON.stringify(result));
  });
});

app.post("/api/v1/person", function(req , res){
	  query = 'INSERT INTO people SET ?';
    var params = {name: req.body.name, age: req.body.age};
    con.query(query, params).then((result) => { 
      console.log(result);
      res.end(JSON.stringify(result));
    });
});

app.get("/drop", function(req , res){
	  query = 'DROP TABLE people';
    con.query(query).then((result) => { 
      console.log(result);
      res.end(JSON.stringify(result));
    });
});

async function createTable() {
  query = "CREATE TABLE IF NOT EXISTS people (personId INTEGER AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(255), age INTEGER)";

  result = await con.query(query);

  console.log(result);
}

createTable();