'use strict'; // all variables must be declared

var mongoose = require('mongoose');

var ItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: 'Item name'
  },
  Created_date: {
    type: Date,
    default: Date.now
  },
  price: {
    type: Number,
    required: 'Item price'
  },
  status: {
    type: [{
      type: String, // can also be another schema variable for a sub-object, or [type] for an array
      enum: ['taxable', 'tax-free']
    }],
    default: ['taxable']
  }
});

module.exports = mongoose.model('Items', ItemSchema);