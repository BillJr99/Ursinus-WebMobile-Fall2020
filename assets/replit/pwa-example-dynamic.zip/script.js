const listCourses = () => {
  const contents = document.querySelector(".contents");

  let content = "";

  const url = "https://pwa-example-server.billjr99.repl.co";
  // fetch returns a promise, which we can process after it is finished
  // converting to json also returns a promise, so we call then again
  fetch(url).then(response => response.json()).then(function(data) {
    let courses = data;

    courses.forEach(
      ({dept, coursenum, coursename, link, img}) => (
        content += `
          <a href="${link}">
          <div class="course">
            <img class="banner" src="${img}" alt="Course banner for ${dept} ${coursenum}" />
            <h1>${dept} ${coursenum}</h1>
            ${coursename}
          </div>
          </a>
        `
      )
    )

    contents.innerHTML = content;  
  }).catch(function(e) {
    console.log(e);
  });
}

document.addEventListener("DOMContentLoaded", listCourses);

// Register service worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", function() {
    navigator.serviceWorker
      .register("./serviceWorker.js")
      .then(res => console.log("service worker registered"))
      .catch(err => console.log("service worker not registered", err))
  })
}