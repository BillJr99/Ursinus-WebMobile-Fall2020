// https://www.digitalocean.com/community/tutorials/a-practical-graphql-getting-started-guide-with-nodejs
// Shared under a Creative Commons BY-NC-SA License
// https://creativecommons.org/licenses/by-nc-sa/4.0/
var express = require('express');
const { graphqlHTTP } = require('express-graphql');
var { buildSchema } = require('graphql');

// Initialize a GraphQL schema
var schema = buildSchema(`
  type Query {
    user(id: Int!): Person
    users(name: String, age: Int): [Person]
  },
  type Person {
    id: Int
    name: String
    age: Int
  }
`);

var users = [
  {
    id: 1,
    name: 'Alex',
    age: '38'
  },
  {
    id: 2,
    name: 'Lee',
    age: '22'
  }
];

// Return a single user
var getUser = function(args) {
  var userID = args.id;
  return users.filter(user => user.id == userID)[0];
}

// Return a list of users
var retrieveUsers = function(args) { 
  if (args.shark) {
    var shark = args.shark;
    return users.filter(user => user.shark === shark);
  } else {
    return users;
  }
}

// Root resolver
var root = {
  user: getUser,  // Resolver function to return user with specific id
  users: retrieveUsers
};

// Create an express server and a GraphQL endpoint
var app = express();
app.use('/graphql', graphqlHTTP({
  schema: schema,  // Must be provided
  rootValue: root,
  graphiql: true,  // Enable GraphiQL when server endpoint is accessed in browser
}));
app.listen(4000, () => console.log('Now browse to https://GraphQLExample.billjr99.repl.co/graphql')); // the :4000 is not required because repl.it forwards it