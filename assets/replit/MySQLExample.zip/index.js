var mysql = require('mysql');

// https://www.w3schools.com/nodejs/nodejs_mysql.asp
// control-shift-S to bring up repl.it terminal
// export DBHOST="db4free.net"
// ...
// node index.js

function quit(result) {
  process.exit(0);
}

function cleanup(result) {
  query(con, "DROP TABLE people", quit);
}

function outputRecords(result) {
  for(var row of result) {
    console.log(row);
  }

  query(con, "DELETE FROM people WHERE name='Bill'", cleanup);
}

function processInsertAlex(result) {
  query(con, "SELECT * FROM people ORDER BY NAME ASC", outputRecords);
}

function processUpdate(result) {
  query(con, "INSERT INTO people (name, age) VALUES ('Alex', 21)", processInsertAlex);
}
function processInsertBill(result) {
  console.log("Inserted " + result.insertId);

  query(con, "UPDATE people SET age=38 WHERE name='Bill'", processUpdate);
}

function processCreateTable(result) {
  query(con, "INSERT INTO people (name, age) VALUES ('Bill', 38)", processInsertBill);
}

function query(con, query, callback=null) {
  con.query(query, function (err, result) {
    if (err) throw err;
    console.log("Result: " + result);

    if(callback) {
      callback(result);
    }
  }); 
}

// con is global to this file
let con = mysql.createConnection({
  host: process.env.DBHOST,
  user: process.env.DBUSER,
  password: process.env.DBPASSWORD,
  database: process.env.DBNAME
});

console.log("Connecting to " + process.env.DBHOST);

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");

  query(con, "CREATE TABLE IF NOT EXISTS people (personId INTEGER AUTO_INCREMENT NOT NULL PRIMARY KEY, name VARCHAR(255), age INTEGER)", processCreateTable);
});